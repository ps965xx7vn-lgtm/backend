# Blog CSS Files

Стили для приложения блога, организованные по компонентам и функциональности.

## 📁 Файлы и их назначение

### `article.css` (1401 строка)

Основные стили для страницы статьи (`article_detail.html`).

**Включает:**

- `.article-header` - шапка статьи с заголовком, мета-информацией
- `.article-meta` - автор, дата, время чтения, сложность
- `.article-content` - markdown контент со стилями для кода, цитат, таблиц
- `.article-tags` - отображение тегов статьи
- `.article-reactions` - кнопки лайков/дизлайков
- `.article-nav` - навигация по серии (предыдущая/следующая статья)
- `.related-articles` - карточки похожих статей
- `.comment-section` - секция комментариев и форма ответа

**Используется в:**

- `blog/article_detail.html`

**Зависимости:**

- Использует вместе с `utils.css` и `reactions.css`

**Ключевые классы:**

```css
.article-container        /* Основной контейнер статьи */
.article-header          /* Шапка с заголовком */
.article-meta            /* Мета-информация */
.article-content         /* Контент статьи */
.article-content pre     /* Блоки кода */
.article-content code    /* Inline код */
.article-tags            /* Теги статьи */
.article-reactions       /* Реакции (лайки/дизлайки) */
.article-nav             /* Навигация серии */
.related-articles        /* Похожие статьи */
.comment-section         /* Комментарии */
```text
---

### `pagination.css` (извлечен из inline)

Стили для компонента пагинации.

**Включает:**

- `.pagination` - контейнер пагинации
- `.page-item` - элемент страницы
- `.page-link` - ссылка на страницу
- `.page-item.active` - активная страница
- `.page-item.disabled` - отключенные кнопки (prev/next на границах)

**Используется в:**

- `blog/includes/pagination.html` (include шаблон)
- `blog/article_list.html`
- `blog/search_results.html`
- `blog/tag_list.html`
- `blog/tag_detail.html`
- `blog/series_list.html`

**Ключевые классы:**

```css
.pagination              /* Flex контейнер */
.page-item              /* Li элемент */
.page-link              /* A элемент с отступами и border */
.page-item.active .page-link  /* Активная страница (синий фон) */
```text
---

### `reactions.css`

Стили для кнопок реакций (лайки/дизлайки) на статьи.

**Включает:**

- `.reactions-container` - контейнер с кнопками
- `.reaction-btn` - кнопка реакции
- `.reaction-btn.liked` - активный лайк
- `.reaction-btn.disliked` - активный дизлайк
- `.reaction-count` - счетчик реакций

**Используется в:**

- `blog/article_detail.html`

**Ключевые классы:**

```css
.reactions-container     /* Flex контейнер */
.reaction-btn           /* Кнопка с иконкой */
.reaction-btn.liked     /* Синий фон для лайка */
.reaction-btn.disliked  /* Красный фон для дизлайка */
.reaction-count         /* Число рядом с кнопкой */
```text
---

### `search-results.css` (извлечен из inline)

Стили для страницы результатов поиска.

**Включает:**

- `.search-header` - шапка с query и количеством результатов
- `.search-results` - контейнер результатов
- `.search-result-item` - карточка одного результата
- `.search-highlight` - подсветка найденных слов
- `.no-results` - сообщение об отсутствии результатов

**Используется в:**

- `blog/search_results.html`

**Зависимости:**

- Работает вместе со скриптом `search-highlight.js`

**Ключевые классы:**

```css
.search-header           /* Заголовок страницы */
.search-results          /* Grid контейнер */
.search-result-item      /* Карточка результата */
.search-highlight        /* Желтый фон для совпадений */
.no-results              /* Центрированное сообщение */
```text
---

### `series-detail.css` (241 строка)

Стили для страницы серии статей (`series_detail.html`).

**Включает:**

- `.series-header` - шапка серии с названием и описанием
- `.series-progress` - общий прогресс прочтения серии
- `.series-timeline` - вертикальный timeline со статьями
- `.timeline-item` - элемент timeline с кружком и линией
- `.article-card` - карточка статьи в серии
- `.read-indicator` - индикатор прочитанности статьи

**Используется в:**

- `blog/series_detail.html`

**Ключевые классы:**

```css
.series-container        /* Основной контейнер */
.series-header          /* Шапка с заголовком */
.series-progress        /* Прогресс-бар серии */
.series-timeline        /* Timeline контейнер */
.timeline-item          /* Li элемент с кружком */
.timeline-connector     /* Вертикальная линия */
.article-card           /* Карточка статьи */
.read-indicator         /* Галочка для прочитанных */
```text
---

### `series.css` (извлечен из inline)

Стили для списка серий (`series_list.html`).

**Включает:**

- `.series-list` - grid контейнер всех серий
- `.series-card` - карточка одной серии
- `.series-info` - информация о серии (название, описание)
- `.series-progress` - прогресс-бар прочтения
- `.series-stats` - статистика (количество статей, прочитано)

**Используется в:**

- `blog/series_list.html`

**Ключевые классы:**

```css
.series-list             /* Grid 2 колонки */
.series-card            /* Карточка с hover эффектом */
.series-info            /* Текстовая информация */
.series-progress        /* Прогресс-бар */
.series-stats           /* Статистика внизу */
```text
---

### `tag-list.css` (извлечен из inline)

Стили для страницы списка тегов (`tag_list.html`).

**Включает:**

- `.tag-search-container` - контейнер поиска тегов
- `.tag-search-input` - input для фильтрации
- `.tag-cloud` - облако тегов
- `.tag-item` - отдельный тег с badge
- `.tag-badge` - badge с количеством статей
- `.no-tags-message` - сообщение "тегов не найдено"

**Используется в:**

- `blog/tag_list.html`

**Зависимости:**

- Работает вместе со скриптом `tag-search.js`

**Ключевые классы:**

```css
.tag-search-container    /* Поиск сверху */
.tag-search-input       /* Input с иконкой */
.tag-cloud              /* Flex контейнер тегов */
.tag-item               /* A элемент тега */
.tag-badge              /* Badge с числом */
.no-tags-message        /* Скрытое сообщение */
```text
---

### `utils.css` (362 строки)

Утилитные классы, используемые во всех шаблонах блога.

**Включает:**

- `.badge-*` - бейджи для категорий, сложности, статуса
- `.card-*` - карточки для статей, комментариев
- `.btn-*` - кнопки разных типов
- `.meta-info` - мета-информация (автор, дата)
- `.difficulty-badge` - бейджи сложности (beginner/intermediate/advanced)
- `.status-badge` - бейджи статуса (published/draft/archived)
- `.tag-badge` - бейджи тегов
- `.loading-spinner` - спиннер загрузки

**Используется в:**

- `blog/home.html`
- `blog/article_list.html`
- `blog/article_detail.html`
- `blog/category_detail.html`
- `blog/series_list.html`
- `blog/series_detail.html`
- `blog/tag_list.html`
- `blog/tag_detail.html`
- `blog/search_results.html`
- `blog/author_detail.html`

**Ключевые классы:**

```css
/* Бейджи */
.badge                   /* Базовый badge */
.badge-primary           /* Синий */
.badge-success           /* Зеленый */
.badge-warning           /* Желтый */
.badge-danger            /* Красный */
.difficulty-beginner     /* Зеленый badge */
.difficulty-intermediate /* Желтый badge */
.difficulty-advanced     /* Красный badge */

/* Карточки */
.card                    /* Базовая карточка */
.card-header             /* Шапка карточки */
.card-body               /* Тело карточки */
.card-footer             /* Подвал карточки */

/* Кнопки */
.btn                     /* Базовая кнопка */
.btn-primary             /* Синяя кнопка */
.btn-secondary           /* Серая кнопка */
.btn-success             /* Зеленая кнопка */
.btn-danger              /* Красная кнопка */

/* Мета-информация */
.meta-info               /* Flex контейнер */
.meta-item               /* Элемент метаданных */
```text
---

## 🏷️ Конвенции именования

### Почему нет префикса "blog-"

Все файлы находятся в директории `static/css/blog/`, поэтому префикс `blog-` был бы избыточным:

```text
✅ Правильно:  static/css/blog/article.css
❌ Избыточно:  static/css/blog/blog-article.css
```text
### Правила именования

1. **Компоненты страниц**: `{page}.css` - стили конкретной страницы
   - `article.css` - для страницы статьи
   - `pagination.css` - для компонента пагинации
   - `search-results.css` - для страницы поиска

2. **Детальные страницы**: `{entity}-detail.css` - детальные страницы сущностей
   - `series-detail.css` - детальная страница серии

3. **Списочные страницы**: `{entity}.css` или `{entity}-list.css`
   - `series.css` - список серий
   - `tag-list.css` - список тегов

4. **Утилиты**: `utils.css` - универсальные утилитные классы
5. **Компоненты**: `{component}.css` - переиспользуемые компоненты
   - `reactions.css` - компонент реакций

---

## 📄 Использование в шаблонах

### Базовая структура

Большинство шаблонов наследуются от `base.html` и подключают CSS так:

```django
{% extends "base.html" %}
{% load static %}

{% block extra_css %}
    <link rel="stylesheet" href="{% static 'css/blog/utils.css' %}">
    <link rel="stylesheet" href="{% static 'css/blog/article.css' %}">
{% endblock %}
```text
### Карта использования

| Шаблон | CSS файлы |
|--------|-----------|
| `article_detail.html` | `utils.css`, `article.css`, `reactions.css` |
| `article_list.html` | `utils.css`, `pagination.css` |
| `series_detail.html` | `utils.css`, `series-detail.css` |
| `series_list.html` | `utils.css`, `series.css`, `pagination.css` |
| `tag_list.html` | `utils.css`, `tag-list.css` |
| `tag_detail.html` | `utils.css`, `pagination.css` |
| `search_results.html` | `utils.css`, `search-results.css`, `pagination.css` |
| `category_detail.html` | `utils.css`, `pagination.css` |
| `author_detail.html` | `utils.css`, `pagination.css` |
| `home.html` | `utils.css` |

### Важно

- **`utils.css`** - подключается везде первым, содержит базовые утилиты
- **`pagination.css`** - подключается на всех страницах со списками
- Специфичные файлы подключаются только на своих страницах

---

## 🎨 Структура стилей

### Организация внутри файлов

Каждый CSS файл организован по секциям:

```css
/* ===================================
   НАЗВАНИЕ КОМПОНЕНТА
   =================================== */

/* Основной контейнер */
.component-container { }

/* Вложенные элементы */
.component-header { }
.component-body { }
.component-footer { }

/* Модификаторы */
.component.active { }
.component.disabled { }

/* Адаптивность */
@media (max-width: 768px) {
    .component-container { }
}
```text
### BEM подобная методология

Используется упрощенная BEM нотация:

```css
.block              /* Блок */
.block-element      /* Элемент блока */
.block.modifier     /* Модификатор */
```text
Примеры:

- `.article-header` (блок-элемент)
- `.article-content` (блок-элемент)
- `.btn.btn-primary` (блок с модификатором)

---

## 🔧 Поддержка и обновление

### Добавление новых стилей

1. **Определите компонент**: Это утилита, страница или компонент?
2. **Выберите файл**:
   - Утилитные классы → `utils.css`
   - Специфичные для страницы → создайте `{page}.css`
   - Переиспользуемый компонент → создайте `{component}.css`
3. **Следуйте именованию**: используйте BEM подобную нотацию
4. **Добавьте комментарии**: секции и сложные селекторы
5. **Обновите README**: добавьте описание нового файла

### Извлечение inline стилей

Если в шаблоне есть `<style>` блоки:

1. **Найдите inline стили**: `grep -r "<style>" src/blog/templates/`
2. **Создайте файл**: `{component}.css`
3. **Перенесите стили**: скопируйте и отформатируйте
4. **Подключите в шаблоне**: `{% load static %}` и `<link rel="stylesheet" href="...">`
5. **Удалите inline**: удалите `<style>` блок
6. **Скопируйте в staticfiles**: `python manage.py collectstatic`

### Collectstatic

После изменения CSS файлов:

```bash

# Из корня проекта

cd src/
python manage.py collectstatic --noinput

# Или с очисткой старых файлов

python manage.py collectstatic --clear --noinput
```text
Файлы копируются в `staticfiles/css/blog/`

---

## 📊 Статистика

- **Всего CSS файлов**: 8
- **Общий объем**: ~2500 строк кода
- **Шаблонов использующих**: 14
- **Утилитных классов**: ~50 (в utils.css)
- **Responsive breakpoints**: 768px, 992px, 1200px

---

## 📝 Changelog

### 2025-01-15

- ✅ Извлечены inline стили из `pagination.html` → `pagination.css`
- ✅ Извлечены inline стили из `series_list.html` → `series.css`
- ✅ Извлечены inline стили из `tag_list.html` → `tag-list.css`
- ✅ Извлечены inline стили из `search_results.html` → `search-results.css`
- ✅ Удален префикс "blog-" из всех файлов (`blog-article.css` → `article.css`)
- ✅ Обновлены все ссылки в шаблонах
- ✅ Создан README.md

### История

- Ранее: все inline стили в шаблонах
- Рефакторинг: разделение на компоненты
- Стандартизация: единые правила именования

---

## 🔗 Связанные документы

- **Шаблоны**: `blog/templates/README.md` - документация HTML шаблонов
- **JavaScript**: `static/js/blog/README.md` - документация JS файлов
- **Приложение**: `blog/README.md` - общая документация блога
- **API**: `BLOG_API_DOCUMENTATION.md` - REST API документация
