# Legal Pages Styles - Стили для юридических страниц

Единая стилистика для всех правовых документов платформы.

## 📁 Файлы

### CSS

- `legal-pages.css` - Основные стили с поддержкой темной/светлой темы

### JavaScript

- `legal-pages.js` - Интерактивные функции (оглавление, прокрутка, кнопка "наверх")

## 🎨 Дизайн

### Цветовая схема

**Светлая тема:**

- Фон: `#ffffff`
- Текст: `#2d3748`
- Акцент: `#3b82f6` (синий)
- Границы: `#e2e8f0`

**Темная тема:**

- Фон: `#0f172a`
- Текст: `#e2e8f0`
- Акцент: `#60a5fa` (светло-синий)
- Границы: `#1e293b`

### Типографика

- **Заголовок страницы**: `clamp(2rem, 4vw, 2.75rem)` - адаптивный размер
- **Заголовок секции**: `1.75rem` (desktop), `1.5rem` (mobile)
- **Подзаголовок**: `1.35rem` (desktop), `1.2rem` (mobile)
- **Текст**: `1rem`, межстрочный интервал `1.8`
- **Списки**: `1rem`, межстрочный интервал `1.7`

## 📱 Адаптивность

### Breakpoints

- **Desktop**: `> 1024px` - Двухколоночный layout (оглавление + контент)
- **Tablet**: `768px - 1024px` - Одноколоночный, оглавление сверху
- **Mobile**: `480px - 768px` - Оптимизированная типографика
- **Small**: `< 480px` - Минимальные отступы, вертикальная мета-информация

### Особенности адаптации

```css
/* Desktop: Оглавление слева, sticky */
.legal-container {
    grid-template-columns: 280px 1fr;
}

/* Tablet/Mobile: Одна колонка */
@media (max-width: 1024px) {
    .legal-container {
        grid-template-columns: 1fr;
    }
}
```text
## 🎯 Структура HTML

### Базовая структура

```html
<div class="legal-page">
    <div class="legal-container">
        <!-- Оглавление -->
        <nav class="legal-toc">
            <h3 class="legal-toc-title">Содержание</h3>
            <ul class="legal-toc-list">
                <li class="legal-toc-item">
                    <a href="#section-1" class="legal-toc-link">Раздел 1</a>
                </li>
                <!-- Подразделы -->
                <ul class="legal-toc-sublist">
                    <li class="legal-toc-item">
                        <a href="#subsection-1-1" class="legal-toc-link">Подраздел 1.1</a>
                    </li>
                </ul>
            </ul>
        </nav>

        <!-- Контент -->
        <main class="legal-content">
            <!-- Шапка -->
            <header class="legal-header">
                <h1 class="legal-title">Название документа</h1>
                <div class="legal-meta">
                    <span class="legal-meta-item">
                        <i class="legal-meta-icon">📅</i>
                        Дата обновления: 15.01.2025
                    </span>
                    <span class="legal-meta-item">
                        <i class="legal-meta-icon">📝</i>
                        Версия: 2.0
                    </span>
                </div>
            </header>

            <!-- Секции -->
            <section id="section-1" class="legal-section">
                <h2 class="legal-section-title">Заголовок секции</h2>

                <p>Текст параграфа...</p>

                <h3 class="legal-subsection-title">Подзаголовок</h3>

                <ul>
                    <li>Пункт списка 1</li>
                    <li>Пункт списка 2</li>
                </ul>

                <div class="legal-highlight">
                    <p><strong>Важно!</strong> Важная информация...</p>
                </div>

                <div class="legal-code">
                    Технический код или адрес
                </div>
            </section>

            <!-- Подвал -->
            <footer class="legal-footer">
                <p class="legal-footer-text">
                    <strong>Вопросы?</strong> Свяжитесь с нами по адресу
                    <a href="mailto:legal@pyschool.ru">legal@pyschool.ru</a>
                </p>
            </footer>
        </main>
    </div>

    <!-- Кнопка "Наверх" -->
    <button class="legal-back-to-top" aria-label="Вернуться наверх">
        ↑
    </button>
</div>
```text
## 🧩 Компоненты

### 1. Оглавление (Table of Contents)

**Классы:**

- `.legal-toc` - Контейнер
- `.legal-toc-title` - Заголовок "Содержание"
- `.legal-toc-list` - Список разделов
- `.legal-toc-link` - Ссылка на раздел
- `.legal-toc-link.active` - Активный раздел
- `.legal-toc-sublist` - Вложенный список

**Поведение:**

- Sticky на desktop (top: 100px)
- Static на mobile/tablet
- Автоматическая подсветка активного раздела

### 2. Списки

**Маркированные списки:**

```html
<ul>
    <li>Пункт 1</li>
    <li>Пункт 2</li>
</ul>
```text
- Кастомные маркеры (синие кружки)
- Вложенные списки (пустые кружки)

**Нумерованные списки:**

```html
<ol>
    <li>Пункт 1</li>
    <li>Пункт 2</li>
</ol>
```text
- Кастомная нумерация (кружки с номерами)

### 3. Выделения

**Важная информация:**

```html
<div class="legal-highlight">
    <p><strong>Важно!</strong> Текст...</p>
</div>
```text
**Код:**

```html
<div class="legal-code">
    technical@pyschool.ru
</div>
```text
**Inline code:**

```html
<p>Используйте <code>POST /api/users</code> для создания...</p>
```text
### 4. Таблицы

```html
<div class="legal-table-wrapper">
    <table class="legal-table">
        <thead>
            <tr>
                <th>Колонка 1</th>
                <th>Колонка 2</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Данные 1</td>
                <td>Данные 2</td>
            </tr>
        </tbody>
    </table>
</div>
```text
### 5. Кнопка "Наверх"

```html
<button class="legal-back-to-top" aria-label="Вернуться наверх">
    <svg>...</svg>
</button>
```text
**Поведение:**

- Показывается после прокрутки > 400px
- Плавная прокрутка наверх
- Hover-эффект с подъемом

## ⚙️ JavaScript функции

### 1. Плавная прокрутка

```javascript
initSmoothScroll()
```text
Обрабатывает клики по ссылкам в оглавлении, плавная прокрутка до секции.

### 2. Подсветка активного раздела

```javascript
initActiveSection()
```text
Использует Intersection Observer для отслеживания видимых секций.

### 3. Кнопка "Наверх"

```javascript
initBackToTop()
```text
Показывает/скрывает кнопку в зависимости от позиции прокрутки.

### 4. Автоматические якоря

```javascript
initAutoAnchors()
```text
Создает ID для секций без них на основе заголовков.

### 5. Копирование ссылки

```javascript
initCopyLink()
```text
Клик по заголовку секции копирует прямую ссылку в буфер обмена.

## 🔧 Кастомизация

### Изменение цветовой схемы

```css
:root {
    --legal-accent: #your-color;  /* Основной акцентный цвет */
    --legal-accent-hover: #your-hover-color;  /* Цвет при наведении */
}

[data-theme="dark"] {
    --legal-accent: #your-dark-color;
}
```text
### Изменение ширины контейнера

```css
.legal-container {
    max-width: 1400px;  /* вместо 1200px */
}
```text
### Изменение ширины оглавления

```css
.legal-container {
    grid-template-columns: 320px 1fr;  /* вместо 280px */
}
```text
## 🎭 Темная тема

Переключение темы через атрибут `data-theme` на элементе `<html>` или `<body>`:

```html
<!-- Светлая тема -->
<html data-theme="light">

<!-- Темная тема -->
<html data-theme="dark">
```text
Или через JavaScript:

```javascript
// Включить темную тему
document.documentElement.setAttribute('data-theme', 'dark');

// Включить светлую тему
document.documentElement.setAttribute('data-theme', 'light');
```text
## 🖨️ Печать

Специальные стили для печати:

- Удаление оглавления и кнопки "наверх"
- Одноколоночный layout
- Удаление теней и анимаций
- Черно-белые ссылки

```css
@media print {
    /* Оптимизация для печати */
}
```text
## 📊 Использование

### Подключение в Django шаблоне

```django
{% load static %}

<link rel="stylesheet" href="{% static 'css/core/legal-pages.css' %}">
<script src="{% static 'js/core/legal-pages.js' %}" defer></script>
```text
### Использование для новых страниц

1. Скопируйте структуру HTML из примера выше
2. Замените контент
3. Добавьте секции с уникальными `id`
4. Обновите оглавление соответствующими ссылками

## ✨ Особенности

- ✅ Полная поддержка темной/светлой темы
- ✅ Адаптивный дизайн (4 breakpoints)
- ✅ Автоматическая подсветка активного раздела
- ✅ Плавная прокрутка по якорям
- ✅ Копирование ссылок на разделы
- ✅ Кнопка "Наверх" с плавной анимацией
- ✅ Оптимизация для печати
- ✅ Accessibility (aria-label, семантические теги)
- ✅ Анимации появления секций
- ✅ Throttled scroll events для производительности

## 📝 Примечания

- Используется CSS Grid для layout
- Все цвета через CSS variables для легкой кастомизации
- JavaScript работает как самовызывающаяся функция (IIFE)
- Отсутствие зависимостей (vanilla JS)
- Совместимость с современными браузерами (ES6+)

## 📄 Применяется для

- `terms_of_service.html` - Условия использования
- `privacy_policy.html` - Политика конфиденциальности
- Будущие документы (Cookie Policy, GDPR Compliance и т.д.)
